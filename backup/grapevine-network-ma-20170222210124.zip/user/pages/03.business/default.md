---
title: Business
---

# Business

Grapevine knows how important technology is to the running and success of your business in this fast moving world. We’ve made our IT services simple and easy to understand with no long term contracts.  We currently provide installations and support to a wide variety of business types within East Midlands

* City Centre Estate Agent
* Residential Care Home
* Day Nursery
* Farm
* Metal Fabrications
* Heavy Goods Vehicle Maintenance

We can quote on new IT equipment and consumable’s being very competitive on pricing as we have a great relationship with our suppliers, why not give us a try for a quote on any IT equipment.
 
**We also provide:**

* Website and email hosting
* Cat 5 \ Fibre optic structured cabling
* Unlimited Remote support from as little as £9 Per month per computer (Inc unlimited telephone support)
* Reduced hourly onsite support rates
* Full server support \ installation
* 24/7 Network monitoring (via 3rd party software)
* Network design and implementation \ support of all existing structured cabling and network structure
* Wireless network design and installation \ support of all existing wireless networks
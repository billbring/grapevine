---
title: intro
image_align: left
taxonomy:
    category:
        - intro
---

We are a Nottingham based IT support company specialising in IT support for [Education](../../education), [Small Business](../../business) and [Home Users](../../home-users). We cover the east midlands and surrounding areas. With over 20 years experience we are passionate about IT and the ongoing support / development of IT systems.

We take pride in our reputation and long standing relationships with our customers.
Call us today for a free no obligation quotation [0115 9788 180](tel:01159788180).
